
import { PageBlueprint } from '../types';

export const pagesData: Record<string, PageBlueprint> = {
  gaushala: {
    id: 'gaushala',
    title: 'Gaushala & Animal Welfare',
    purpose: 'Highlight ethical livestock management',
    tone: 'Compassionate yet professional',
    sections: [
      {
        title: 'Compassionate Care Practices',
        description: 'Our pilot facility prioritizes the physical and mental well-being of every animal. This includes spacious shelters, periodic medical checks, and high-quality nutrition.',
        points: ['Standardized feeding protocols', 'Veterinary monitoring logs', 'Open-access paddocks'],
        visualHint: 'Facility Layout Illustration',
        downloadData: {
          filename: 'Animal_Welfare_Standards_BBP.txt',
          label: 'Download Welfare Standards',
          content: 'Bundelkhand Bio Power: Animal Welfare SOPs\n1. Nutrition: Minimum 10kg green fodder per adult unit.\n2. Space: 120 sq.ft per animal in shaded areas.\n3. Health: Bi-weekly veterinary audits.'
        }
      },
      {
        title: 'The Nandi Welfare Initiative',
        description: 'Focusing on non-milking bulls, who are often neglected in traditional dairy systems. We provide them with meaningful engagement through treadmill systems that mirror natural migratory movement.',
        points: ['Ethical workload management', 'Musculoskeletal health monitoring', 'No-cull policy implementation'],
        visualHint: 'Bull Care Cycle Diagram'
      }
    ]
  },
  'nandi-rath': {
    id: 'nandi-rath',
    title: 'Nandi Rath: Bull Treadmill Energy',
    purpose: 'Explain mechanical-to-electrical conversion',
    tone: 'Technical and Engineering-focused',
    sections: [
      {
        title: 'The Mechanical Advantage',
        description: 'The Nandi Rath system uses a high-efficiency gearbox-based treadmill. As the bull walks at a natural pace, the mechanical energy is stepped up to drive a generator.',
        points: ['High-torque gearbox integration', 'Low-RPM permanent magnet generator', 'Variable walking speed compensation'],
        visualHint: 'Gearbox Mechanism Diagram',
        downloadData: {
          filename: 'Nandi_Rath_Technical_Specs.txt',
          label: 'Download Engineering Specs',
          content: 'TECHNICAL SPECIFICATIONS: NANDI RATH MK-I\nGearbox Ratio: 1:120\nGenerator: 5kW PMG @ 300 RPM\nEfficiency: 82% mechanical-to-electrical\nSafety: Magnetic braking system.'
        }
      },
      {
        title: 'Health & Energy Nexus',
        description: 'Research suggests that controlled walking improves the cardiovascular health of bulls. Our system treats electricity as a by-product of a required exercise routine.',
        points: ['Real-time heart rate tracking', 'Automated rest-cycle triggers', 'Daily energy yield per animal metrics'],
        visualHint: 'Energy vs. Health Chart'
      }
    ]
  },
  biogas: {
    id: 'biogas',
    title: 'Biogas & Bio-CNG Infrastructure',
    purpose: 'Core energy backbone documentation',
    tone: 'Industrial and Process-oriented',
    sections: [
      {
        title: 'Anaerobic Digestion Process',
        description: 'Utilizing cow dung and agricultural residue, our anaerobic digesters produce a rich stream of biogas.',
        points: ['Thermophilic digestion modules', 'Feedstock optimization (Dung:Agro-waste)', 'Temperature and pH monitoring systems'],
        visualHint: 'Digester Process Flow'
      },
      {
        title: 'Gas Purification & Bio-CNG',
        description: 'The raw biogas is scrubbed to remove CO₂ and H₂S, resulting in high-purity methane (Bio-CNG) suitable for vehicle fuel or stationary engines.',
        points: ['Pressure Swing Adsorption (PSA) technology', 'Compressor safety protocols', 'Bottling and distribution logistics'],
        visualHint: 'Scrubbing Unit Illustration',
        downloadData: {
          filename: 'Bio_CNG_Purity_Report.txt',
          label: 'Download Purity Analysis',
          content: 'GAS ANALYSIS REPORT\nMethane (CH4): 96.4%\nCarbon Dioxide (CO2): < 2%\nHydrogen Sulfide (H2S): < 10 ppm\nCalorific Value: 52.1 MJ/kg'
        }
      }
    ]
  },
  'by-products': {
    id: 'by-products',
    title: 'Circular By-Products & Fertilizers',
    purpose: 'Zero-waste value chain explanation',
    tone: 'Environmental and Agricultural',
    sections: [
      {
        title: 'Bio-Slurry Valorization',
        description: 'The nitrogen-rich slurry from the digester is the foundation of our organic fertilizer line.',
        points: ['Nutrient analysis (N-P-K profiles)', 'Solid-liquid separation techniques', 'Application-ready bio-liquid production'],
        visualHint: 'Slurry Processing Flow'
      },
      {
        title: 'Solid Fuel Modules',
        description: 'Residual fibrous waste is converted into bio-coal and briquettes, providing a sustainable alternative to traditional fuel wood.',
        points: ['Briquette compression technology', 'Calorific value testing', 'Carbon-neutral combustion profiles'],
        visualHint: 'Bio-Coal Briquette Visual'
      }
    ]
  },
  dairy: {
    id: 'dairy',
    title: 'Dairy & Value-Added Products',
    purpose: 'Secondary income and branding pilot',
    tone: 'Operational and Branding-focused',
    sections: [
      {
        title: 'Pure Milk Value Addition',
        description: 'While energy is our primary focus, our milking cows provide a base for high-quality, ethically produced dairy products.',
        points: ['Traditional Ghee (Bilona method)', 'Fresh Paneer and Buttermilk', 'Zero-adulteration supply chain'],
        visualHint: 'Product Range Illustration'
      },
      {
        title: 'Pilot Branding Concept',
        description: 'Testing the market viability of "Gau-Energy" branded products where consumers support renewable energy by buying dairy.',
        points: ['Consumer trust markers', 'Local cooperative distribution', 'Value-based pricing research'],
        visualHint: 'Packaging Prototype'
      }
    ]
  },
  waste: {
    id: 'waste',
    title: 'Integrated Waste Management',
    purpose: 'Broader environmental cleanup logic',
    tone: 'Scientific and Industrial',
    sections: [
      {
        title: 'Plastic Pyrolysis Unit',
        description: 'A dedicated module to handle local plastic waste, converting it into industrial-grade fuel oil via thermal decomposition.',
        points: ['Low-emission reactor design', 'Fractional distillation of plastic oil', 'By-product (Carbon Black) utilization'],
        visualHint: 'Pyrolysis Reactor Diagram'
      },
      {
        title: 'Biodiesel Production',
        description: 'Converting used cooking oil (UCO) from nearby areas into biodiesel, further diversifying the campus fuel output.',
        points: ['Transesterification process', 'Glycerol recovery and processing', 'Quality testing (ASTM standards)'],
        visualHint: 'Biodiesel Flowchart'
      }
    ]
  },
  renewables: {
    id: 'renewables',
    title: 'Renewable Power Support',
    purpose: 'Hybrid power system context',
    tone: 'Systems Engineering',
    sections: [
      {
        title: 'Solar & Wind Integration',
        description: 'To ensure 24/7 campus power, the bovine-energy system is supported by rooftop solar and small-scale wind turbines.',
        points: ['Hybrid microgrid management', 'Battery energy storage systems (BESS)', 'Net-metering for excess generation'],
        visualHint: 'Hybrid Grid Architecture'
      }
    ]
  },
  future: {
    id: 'future',
    title: 'Green Hydrogen & Bio-Ethanol',
    purpose: 'Future-proofing and R&D scope',
    tone: 'Visionary and Academic',
    sections: [
      {
        title: 'Hydrogen Research Module',
        description: 'Investigating the use of excess renewable power for electrolysis to produce Green Hydrogen.',
        points: ['Electrolyzer scale-up studies', 'Storage and safety research', 'Integration with fuel cell vehicles'],
        visualHint: 'Future Labs Concept'
      },
      {
        title: 'Lignocellulosic Bio-Ethanol',
        description: 'Future plans include converting agricultural waste residues into bio-ethanol for fuel blending.',
        points: ['Enzymatic hydrolysis optimization', 'Fermentation scalability research', 'Circular ethanol-to-fuel loop'],
        visualHint: 'Bio-Ethanol Process Diagram'
      }
    ]
  },
  model: {
    id: 'model',
    title: 'Integrated Pilot Model',
    purpose: 'Holistic circular economy overview',
    tone: 'Structural and Macro-level',
    sections: [
      {
        title: 'The Circular Flow',
        description: 'This page illustrates how every input (water, feed, waste) results in a valuable output (energy, food, fertilizer), creating a closed-loop system.',
        points: ['Inter-module connectivity map', 'Resource balance sheets', 'Waste-to-wealth conversion ratios'],
        visualHint: 'Master Circular Flow Diagram',
        downloadData: {
          filename: 'Circular_Economy_Blueprint.txt',
          label: 'Download System Blueprint',
          content: 'INTEGRATED CIRCULAR ECONOMY BLUEPRINT\nInputs: 4 tons dung/day, 1 ton plastic/month.\nOutputs: 120 units electricity/day, 40 kg Bio-CNG/day, 3 tons Bio-Fertilizer/day.'
        }
      }
    ]
  },
  validation: {
    id: 'validation',
    title: 'Research, Validation & Impact',
    purpose: 'Scientific credibility and data',
    tone: 'Academic and Evidence-based',
    sections: [
      {
        title: 'Pilot Objectives & KPIs',
        description: 'We track specific metrics to validate the success of the model across environmental, social, and economic parameters.',
        points: ['Total carbon footprint reduction', 'Rural employment generation data', 'Energy EROI (Energy Return on Investment)'],
        visualHint: 'KPI Dashboard',
        downloadData: {
          filename: 'Impact_Report_Q1_2024.txt',
          label: 'Download Impact Report',
          content: 'IMPACT REPORT - QUARTER 1 2024\nCarbon Avoided: 45.2 Tons CO2e\nDirect Jobs Created: 14\nCommunity Outreach: 4 Villages\nValidation: Third-party audit pending.'
        }
      }
    ]
  },
  media: {
    id: 'media',
    title: 'Media, Research & Updates',
    purpose: 'News, whitepapers and transparency',
    tone: 'Informative and Current',
    sections: [
      {
        title: 'Whitepapers & Reports',
        description: 'A repository of technical documents, research papers, and periodic progress reports for public and academic review.',
        points: ['Quarterly Impact Reports', 'Technical Design Documents', 'Government Submission Papers'],
        visualHint: 'Document Archive Interface',
        downloadData: {
          filename: 'BBP_Full_Project_Whitepaper.txt',
          label: 'Download Full Whitepaper',
          content: 'PROJECT WHITEPAPER: INTEGRATED BIO-ENERGY CAMPUS\nAuthor: Research Wing, Bundelkhand Bio Power Pvt Ltd\nAbstract: This paper explores the techno-economic feasibility of using bovine mechanical energy as a primary driver for rural microgrids...'
        }
      }
    ]
  },
  contact: {
    id: 'contact',
    title: 'Contact & Collaboration',
    purpose: 'Engagement and inquiry',
    tone: 'Formal and Accessible',
    sections: [
      {
        title: 'Partner with Us',
        description: 'We invite researchers, government bodies, and sustainability enthusiasts to visit our pilot site and explore collaboration opportunities.',
        points: ['Visit Request Protocol', 'Internship & Research Inquiries', 'Technical Advisory Board'],
        visualHint: 'Contact Form Layout',
        downloadData: {
          filename: 'Collaboration_Brochure.txt',
          label: 'Download Partnership Info',
          content: 'PARTNERSHIP OPPORTUNITIES\n1. R&D Collaboration: Joint publishing and lab access.\n2. CSR Partnership: Scale the model to 10 more districts.\n3. Government Liaison: Policy advocacy for gaushala-based Bio-CNG.'
        }
      }
    ]
  }
};
