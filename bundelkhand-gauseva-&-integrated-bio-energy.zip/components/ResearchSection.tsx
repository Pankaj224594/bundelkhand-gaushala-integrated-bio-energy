
import React from 'react';
import { SectionContent } from '../types';
import { Download } from 'lucide-react';

interface ResearchSectionProps {
  content: SectionContent;
  index: number;
}

const ResearchSection: React.FC<ResearchSectionProps> = ({ content, index }) => {
  const handleDownload = () => {
    if (!content.downloadData) return;
    const blob = new Blob([content.downloadData.content], { type: 'text/plain' });
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = content.downloadData.filename;
    document.body.appendChild(a);
    a.click();
    window.URL.revokeObjectURL(url);
    document.body.removeChild(a);
  };

  return (
    <div className={`py-12 px-6 lg:px-0 ${index % 2 === 1 ? 'bg-slate-50' : 'bg-white'}`}>
      <div className="max-w-4xl mx-auto">
        <div className="flex flex-col md:flex-row gap-8 items-start">
          <div className="flex-1">
            <span className="text-green-700 font-bold text-xs tracking-tighter uppercase mb-2 block">
              Module {String(index + 1).padStart(2, '0')}
            </span>
            <h2 className="text-2xl font-bold text-slate-800 mb-4">{content.title}</h2>
            <p className="text-slate-600 leading-relaxed mb-6 whitespace-pre-wrap">
              {content.description}
            </p>
            {content.points && (
              <ul className="space-y-3 mb-8">
                {content.points.map((point, i) => (
                  <li key={i} className="flex items-start">
                    <div className="mt-1 mr-3 h-1.5 w-1.5 rounded-full bg-green-500 flex-shrink-0" />
                    <span className="text-sm text-slate-700 leading-snug">{point}</span>
                  </li>
                ))}
              </ul>
            )}
            
            {content.downloadData && (
              <button 
                onClick={handleDownload}
                className="inline-flex items-center px-4 py-2 bg-green-700 text-white rounded-md text-xs font-bold uppercase tracking-widest hover:bg-green-800 transition-colors shadow-sm"
              >
                <Download className="h-4 w-4 mr-2" />
                {content.downloadData.label}
              </button>
            )}
          </div>
          {content.visualHint && (
            <div className="w-full md:w-64 flex-shrink-0 border-2 border-dashed border-slate-200 rounded-lg bg-white p-6 flex flex-col items-center justify-center text-center">
              <div className="text-slate-400 mb-2">
                 <svg className="w-8 h-8 mx-auto" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z" />
                 </svg>
              </div>
              <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">{content.visualHint}</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default ResearchSection;
